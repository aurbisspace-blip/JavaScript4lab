/*8.      Лабораторная работа №3. Перегрузка операций

Составить описание класса для определения одномерных массивов строк фиксированной длины. Предусмотреть возможность обращения к отдельным строкам массива по индексам, с контролем выхода за пределы индексов, возможность задания произвольных границ индексов при создании объекта и выполнения операций поэлементного сцепления двух массивов с образованием нового массива, слияния двух массивов с исключением повторяющихся элементов, печати (вывода на экран) элементов массива по индексам и всего массива. 
*/
#include <iostream>
#include <string>
using namespace std;

class StringArray {
private:
    string* data;
    int lower, upper;

public:
    // Конструктор
    StringArray(int l, int u) {
        if (l > u) {
            cout << "Ошибка границ!\n";
            exit(1);
        }

        lower = l;
        upper = u;
        data = new string[upper - lower + 1];
    }

    // Деструктор
    ~StringArray() {
        delete[] data;
    }

    // Доступ по индексу с проверкой
    string& operator[](int index) {
        if (index < lower || index > upper) {
            cout << "Выход за границы массива!\n";
            exit(1);
        }
        return data[index - lower];
    }

    // Константная версия
    const string& operator[](int index) const {
        if (index < lower || index > upper) {
            cout << "Выход за границы массива!\n";
            exit(1);
        }
        return data[index - lower];
    }

    // Получить размер
    int size() const {
        return upper - lower + 1;
    }

    // Поэлементное сцепление (+)
    StringArray operator+(const StringArray& other) const {
        if (size() != other.size()) {
            cout << "Массивы разного размера!\n";
            exit(1);
        }

        StringArray result(lower, upper);

        for (int i = lower; i <= upper; i++) {
            result[i] = (*this)[i] + other[i];
        }

        return result;
    }

    // Проверка на наличие строки
    bool contains(const string& value) const {
        for (int i = lower; i <= upper; i++) {
            if ((*this)[i] == value)
                return true;
        }
        return false;
    }

    // Слияние без повторов (*)
    StringArray operator*(const StringArray& other) const {
        int newSize = size() + other.size();
        StringArray temp(0, newSize - 1);

        int k = 0;

        // добавляем первый массив
        for (int i = lower; i <= upper; i++) {
            temp[k++] = (*this)[i];
        }

        // добавляем второй без повторов
        for (int i = other.lower; i <= other.upper; i++) {
            if (!temp.contains(other[i])) {
                temp[k++] = other[i];
            }
        }

        // финальный массив
        StringArray result(0, k - 1);
        for (int i = 0; i < k; i++) {
            result[i] = temp[i];
        }

        return result;
    }

    // Вывод одного элемента
    void printIndex(int index) const {
        cout << "[" << index << "] = " << (*this)[index] << endl;
    }

    // Вывод всего массива
    void print() const {
        for (int i = lower; i <= upper; i++) {
            cout << "[" << i << "] = " << (*this)[i] << endl;
        }
    }
};

int main() {
    // создаем массивы с произвольными границами
    StringArray a(-1, 2);
    StringArray b(-1, 2);

    // заполняем
    a[-1] = "Hi";
    a[0] = "Cat";
    a[1] = "Dog";
    a[2] = "Sun";

    b[-1] = "!";
    b[0] = "Fish";
    b[1] = "Dog";
    b[2] = "Moon";

    cout << "Массив A:\n";
    a.print();

    cout << "\nМассив B:\n";
    b.print();

    // сцепление
    StringArray c = a + b;
    cout << "\nСцепление (A + B):\n";
    c.print();

    // слияние без повторов
    StringArray d = a * b;
    cout << "\nСлияние без повторов (A * B):\n";
    d.print();

    // вывод одного элемента
    cout << "\nЭлемент A[1]:\n";
    a.printIndex(1);

    return 0;
}